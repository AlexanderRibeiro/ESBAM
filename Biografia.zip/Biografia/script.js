document.getElementById('feedbackForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    // You can perform additional validation here if needed

    // Display thank you message using an alert
    alert('Obrigado pelo seu feedback!');
});
